﻿using KMSolutionsEmployee.Models;
using Microsoft.EntityFrameworkCore;

namespace KMSolutionsEmployee.Services
{
    public class EmployeeServices
    {
        public static List<Employee> GetAllEmployees()
        {
            using (KmsolutionsEmployeeContext db = new())
            {

                return db.Employees
                        .Include(x => x.EmployeeCertificates)
                        .Include(x => x.EmployeeJobHistories)
                        .Include(x => x.EmployeePayrolls)
                        .ToList();
            }
        }

        public static async Task<List<Employee>> GetAllEmployeesAsync()
        {
            using (KmsolutionsEmployeeContext db = new())
            {
                return await db.Employees
                        .Include(x => x.EmployeeCertificates)
                        .Include(x => x.EmployeeJobHistories)
                        .Include(x => x.EmployeePayrolls)
                        .ToListAsync();
            }
        }
    }
}
