﻿namespace KM2SolutionsWebApp.API.Requests
{
    public class UpdateEmployeeCertificateRequest
    {
        public Guid Id { get; set; }

        public Guid? EmployeeId { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime Date { get; set; }
    }
}
