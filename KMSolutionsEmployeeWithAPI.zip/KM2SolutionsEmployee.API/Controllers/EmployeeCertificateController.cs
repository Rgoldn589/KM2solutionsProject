﻿using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsEmployee.Data;
using KMSolutionsEmployee.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeCertificateController : ControllerBase
    {
        private readonly KM2SolutionsEmployeeContext _context;

        public EmployeeCertificateController(KM2SolutionsEmployeeContext context)
        {
            _context = context;
        }

        [HttpGet("GetEmployeeCertificates")]
        public async Task<IActionResult> GetEmployeeCertificates()
        {

            var employeeCertifications = await _context.EmployeeCertificate
                 .ToListAsync();

            var employeeCertificationsJson = JsonConvert.SerializeObject(employeeCertifications, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeeCertificationsJson);
        }

        [HttpGet("GetEmployeeCertificate")]
        public async Task<IActionResult> GetEmployeeCertificate(GetEmployeeDataRequest request)
        {
            var employeeCertifications = await _context.EmployeeCertificate
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            var employeeCertificationsJson = JsonConvert.SerializeObject(employeeCertifications, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeeCertificationsJson);

        }

        [HttpPost("UpdateEmployeeCertificate")]
        public async Task<IActionResult> UpdateEmployeeCertificate(UpdateEmployeeCertificateRequest request)
        {
            var employeeCertifications = await _context.EmployeeCertificate
              .FirstOrDefaultAsync(e => e.Id.Equals(request.Id));

            if (employeeCertifications == null)
            {
                await _context.EmployeeCertificate.AddAsync(new EmployeeCertificate()
                {
                    Id = request.Id,
                    Name = request.Name,
                    EmployeeId = request.EmployeeId,
                    Description = request.Description,
                    Date = request.Date,
                });
            }
            else
            {
                employeeCertifications.Name = request.Name;
                employeeCertifications.Description = request.Description;
                employeeCertifications.Date = request.Date;
            }

            await _context.SaveChangesAsync();
            return Ok("Success");
        }

        [HttpPost("DeleteEmployeeCertificate")]
        public async Task<IActionResult> DeleteEmployee(GetEmployeeDataRequest request)
        {
            var employeeCertifications = await _context.EmployeeCertificate
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            if (employeeCertifications == null)
            {
                return NotFound("fail");
            }

            _context.EmployeeCertificate.Remove(employeeCertifications);
            await _context.SaveChangesAsync();
            return Ok("Success");
        }
    }
}
