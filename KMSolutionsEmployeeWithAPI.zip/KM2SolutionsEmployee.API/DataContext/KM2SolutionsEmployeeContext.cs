﻿using Microsoft.EntityFrameworkCore;
using KMSolutionsEmployee.Models;

namespace KM2SolutionsEmployee.Data
{
    public class KM2SolutionsEmployeeContext : DbContext
    {
        public KM2SolutionsEmployeeContext (DbContextOptions<KM2SolutionsEmployeeContext> options)
            : base(options)
        {
        }

        public DbSet<Employee> Employee { get; set; } = default!;
        public DbSet<EmployeeCertificate> EmployeeCertificate { get; set; } = default!;
        public DbSet<EmployeeJobHistory> EmployeeJobHistory { get; set; } = default!;
        public DbSet<EmployeePayroll> EmployeePayroll { get; set; } = default!;
    }
}
