﻿using System;
using System.Collections.Generic;

namespace KMSolutionsEmployee.Models;

public partial class EmployeePayroll
{
    public Guid Id { get; set; }

    public Guid? EmployeeId { get; set; }

    public DateTime? Date { get; set; }

    public decimal Amount { get; set; }

    public virtual Employee? Employee { get; set; }
}
