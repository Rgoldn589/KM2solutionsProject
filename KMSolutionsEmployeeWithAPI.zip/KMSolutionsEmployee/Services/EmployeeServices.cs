﻿using KMSolutionsEmployee.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Configuration;
using System.Net.Http;

namespace KMSolutionsEmployee.Services
{
    public class EmployeeServices
    {
        public async Task<string> MakeAPICall(HttpMethod method, string http, string? json = null)
        {

            var httpBase = ConfigurationManager.AppSettings["HTTP"];

            var httpClient = new HttpClient();
            var newRequest = new HttpRequestMessage(method, httpBase + http);

            if (json != null)
            {
                newRequest.Content = new StringContent(json, null, "application/json");
            }

            var response = await httpClient.SendAsync(newRequest);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }
    }
}
