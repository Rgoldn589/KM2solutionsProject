﻿using System.ComponentModel.DataAnnotations;

namespace KM2SolutionsWebApp.Models
{
    public partial class EmployeeJobHistory : IValidatableObject
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        [Required]
        public string Job { get; set; } = null!;

        [Required]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? StartDate { get; set; }

        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? EndDate { get; set; }

        [Required]
        [Display(Name = "Total Hours")]
        public decimal TotalHours { get; set; }

        public virtual Employee? Employee { get; set; }

    }
}
