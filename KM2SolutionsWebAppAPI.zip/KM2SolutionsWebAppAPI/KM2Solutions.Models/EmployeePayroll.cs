﻿using System.ComponentModel.DataAnnotations;

namespace KM2SolutionsWebApp.Models
{
    public class EmployeePayroll
    {
        public Guid Id { get; set; }

        public Guid? EmployeeId { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime? Date { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal Amount { get; set; }

        public virtual Employee? Employee { get; set; }
    }
}
