﻿using System.ComponentModel.DataAnnotations;

namespace KM2SolutionsWebApp.Models
{
    public partial class EmployeeJobHistory
    {
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (EndDate < StartDate)
            {
                yield return new ValidationResult(
                    errorMessage: "End Date must be greater than Start Date",
                    memberNames: new[] { "EndDate" }
               );
            }
        }
    }
}
