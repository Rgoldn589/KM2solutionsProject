﻿namespace KM2SolutionsWebApp.Models
{
    public partial class Employee
    {
        public string EmployeeFullName
        {
            get { return FirstName + " " + LastName; }
        }

   

    }
}
