﻿using System.ComponentModel.DataAnnotations;

namespace KM2SolutionsWebApp.Models
{
    public partial class Employee
    {
        public Guid Id { get; set; }

        [Display(Name = "First Name")]
        [Required]
        public string FirstName { get; set; } = null!;

        [Display(Name = "Last Name")]
        [Required]
        public string LastName { get; set; } = null!;

        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        [Display(Name = "Start Date")]
        [Required]
        public DateTime StartDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        [Display(Name = "End Date")]
        public DateTime? EndDate { get; set; }

        public List<EmployeeCertificate> EmployeeCertificates { get; set; }

        public List<EmployeeJobHistory> EmployeeJobHistories { get; set; }

        public List<EmployeePayroll> EmployeePayrolls { get; set; }
    }
}
