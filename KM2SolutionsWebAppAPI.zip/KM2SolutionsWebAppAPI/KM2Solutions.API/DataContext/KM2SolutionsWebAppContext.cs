﻿using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Models;

namespace KM2SolutionsWebApp.Data
{
    public class KM2SolutionsWebAppContext : DbContext
    {
        public KM2SolutionsWebAppContext (DbContextOptions<KM2SolutionsWebAppContext> options)
            : base(options)
        {
        }

        public DbSet<Employee> Employee { get; set; } = default!;
        public DbSet<EmployeeCertificate> EmployeeCertificate { get; set; } = default!;
        public DbSet<EmployeeJobHistory> EmployeeJobHistory { get; set; } = default!;
        public DbSet<EmployeePayroll> EmployeePayroll { get; set; } = default!;
    }
}
