﻿using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsWebApp.Data;
using KM2SolutionsWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeJobHistoryController : ControllerBase
    {
        private readonly KM2SolutionsWebAppContext _context;

        public EmployeeJobHistoryController(KM2SolutionsWebAppContext context)
        {
            _context = context;
        }

        [HttpGet("GetEmployeeJobHistories")]
        public async Task<IActionResult> GetEmployeeJobHistories()
        {

            var employeeJobHistories = await _context.EmployeeJobHistory.ToListAsync();

            var employeesJobHistoriesJson = JsonConvert.SerializeObject(employeeJobHistories, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeesJobHistoriesJson);
        }

        [HttpGet("GetEmployeeJobHistory")]
        public async Task<IActionResult> GetEmployeeJobHistory(GetEmployeeDataRequest request)
        {
            var employeeJobHistories = await _context.EmployeeJobHistory
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            var employeesJobHistoriesJson = JsonConvert.SerializeObject(employeeJobHistories, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeesJobHistoriesJson);

        }

        [HttpPost("UpdateEmployeeJobHistory")]
        public async Task<IActionResult> UpdateEmployeeJobHistory(UpdateEmployeeJobHistoryRequest request)
        {
            var employeeJobHistories = await _context.EmployeeJobHistory
              .FirstOrDefaultAsync(e => e.Id.Equals(request.Id));

            if (employeeJobHistories == null)
            {
                await _context.EmployeeJobHistory.AddAsync(new EmployeeJobHistory()
                {
                    Id = request.Id,
                    EmployeeId = request.EmployeeId,
                    Job = request.Job,
                    TotalHours = request.TotalHours,
                    StartDate = request.StartDate,
                    EndDate = request.EndDate
                });
            }
            else
            {
                employeeJobHistories.Job = request.Job;
                employeeJobHistories.TotalHours = request.TotalHours;
                employeeJobHistories.StartDate = request.StartDate;
                employeeJobHistories.EndDate = request.EndDate;
            }

            await _context.SaveChangesAsync();
            return Ok("Success");
        }

        [HttpPost("DeleteEmployeeJobHistory")]
        public async Task<IActionResult> DeleteEmployeeJobHistory(GetEmployeeDataRequest request)
        {
            var employeeJobHistories = await _context.EmployeeJobHistory
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            if (employeeJobHistories == null)
            {
                return NotFound("fail");
            }

            _context.EmployeeJobHistory.Remove(employeeJobHistories);
            await _context.SaveChangesAsync();
            return Ok("Success");
        }
    }
}
