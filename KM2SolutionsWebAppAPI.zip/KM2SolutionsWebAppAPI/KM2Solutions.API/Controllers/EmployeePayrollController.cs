﻿using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsWebApp.Data;
using KM2SolutionsWebApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeePayrollController : ControllerBase
    {
        private readonly KM2SolutionsWebAppContext _context;

        public EmployeePayrollController(KM2SolutionsWebAppContext context)
        {
            _context = context;
        }

        [HttpGet("GetEmployeePayrolls")]
        public async Task<IActionResult> GetEmployeePayrolls()
        {

            var employeePayrolls = await _context.EmployeePayroll.ToListAsync();

            var employeePayrollJson = JsonConvert.SerializeObject(employeePayrolls, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeePayrollJson);
        }

        [HttpGet("GetEmployeePayroll")]
        public async Task<IActionResult> GetEmployeePayroll(GetEmployeeDataRequest request)
        {
            var employeePayroll = await _context.EmployeePayroll
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            var employeePayrollJson = JsonConvert.SerializeObject(employeePayroll, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeePayrollJson);

        }

        [HttpPost("UpdateEmployeePayroll")]
        public async Task<IActionResult> UpdateEmployeePayroll(UpdateEmployeePayrollRequest request)
        {
            var employeePayroll = await _context.EmployeePayroll
                .FirstOrDefaultAsync(e => e.Id.Equals(request.Id));

            if (employeePayroll == null)
            {
                await _context.EmployeePayroll.AddAsync(new EmployeePayroll()
                {
                    Id = request.Id,
                    EmployeeId = request.EmployeeId,
                    Date = request.Date,
                    Amount = request.Amount
                });
            }
            else
            {
                employeePayroll.Id = request.Id;
                employeePayroll.EmployeeId = request.EmployeeId;
                employeePayroll.Date = request.Date;
                employeePayroll.Amount = request.Amount;
            }

            await _context.SaveChangesAsync();
            return Ok("Success");
        }

        [HttpPost("DeleteEmployeePayroll")]
        public async Task<IActionResult> DeleteEmployeeJobHistory(GetEmployeeDataRequest request)
        {
            var employeePayroll = await _context.EmployeePayroll
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            if (employeePayroll == null)
            {
                return NotFound("fail");
            }

            _context.EmployeePayroll.Remove(employeePayroll);
            await _context.SaveChangesAsync();
            return Ok("Success");
        }
    }
}
