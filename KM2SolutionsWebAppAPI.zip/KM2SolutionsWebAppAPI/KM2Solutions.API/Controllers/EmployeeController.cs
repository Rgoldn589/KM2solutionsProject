﻿using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsWebApp.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using KM2SolutionsWebApp.Models;

namespace KM2Solutions.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly KM2SolutionsWebAppContext _context;

        public EmployeeController(KM2SolutionsWebAppContext context)
        {
            _context = context;
        }

        [HttpGet("GetEmployees")]
        public async Task<IActionResult> GetEmployees()
        {

            var employees = await _context.Employee
                 .ToListAsync();

            var employeesJson = JsonConvert.SerializeObject(employees, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeesJson);
        }

        [HttpGet("GetEmployee")]
        public async Task<IActionResult> GetEmployee(GetEmployeeDataRequest request)
        {
            var employee = await _context.Employee
                .Include(P => P.EmployeePayrolls)
                .Include(C => C.EmployeeCertificates)
                .Include(h => h.EmployeeJobHistories)
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            var employeesJson = JsonConvert.SerializeObject(employee, Formatting.Indented,
                new JsonSerializerSettings
                {
                    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                });

            return Ok(employeesJson);

        }

        [HttpPost("UpdateEmployee")]
        public async Task<IActionResult> UpdateEmployee(UpdateEmployeeRequest request)
        {
            var employee = await _context.Employee
              .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            if (employee == null)
            {
                await _context.Employee.AddAsync(new Employee()
                {
                    Id = request.ID,
                    FirstName = request.FirstName,
                    LastName = request.LastName,
                    StartDate = request.StartDate,
                    EndDate = request.EndDate
                });
            }
            else
            {
                employee.FirstName = request.FirstName;
                employee.LastName = request.LastName;
                employee.StartDate = request.StartDate;
                employee.EndDate = request.EndDate;
            }

            await _context.SaveChangesAsync();
            return Ok("Success");
        }

        [HttpPost("DeleteEmployee")]
        public async Task<IActionResult> DeleteEmployee(GetEmployeeDataRequest request)
        {

            var employee = await _context.Employee
                .FirstOrDefaultAsync(e => e.Id.Equals(request.ID));

            if (employee == null)
            {
                return NotFound("fail");
            }

            _context.Employee.Remove(employee);
            await _context.SaveChangesAsync();
            return Ok("Success");
        }
    }
}
