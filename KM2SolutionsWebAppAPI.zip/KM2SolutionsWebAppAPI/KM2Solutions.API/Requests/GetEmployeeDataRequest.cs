﻿using static System.Net.WebRequestMethods;

namespace KM2SolutionsWebApp.API.Requests
{
    public class GetEmployeeDataRequest 
    {
        public Guid ID { get; set; }
    }
}
