﻿using System.ComponentModel.DataAnnotations;

namespace KM2SolutionsWebApp.API.Requests
{
    public class UpdateEmployeeJobHistoryRequest
    {
        public Guid Id { get; set; }
        public Guid EmployeeId { get; set; }
        public string Job { get; set; } = null!;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public decimal TotalHours { get; set; }
    }
}
