﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Models;
using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsWebApp.Services;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeePayrollsController : Controller
    {

        // GET: EmployeePayrolls
        public async Task<IActionResult> Index(Guid id)
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employeepayroll/GetEmployeePayrolls");
            var employees = new List<EmployeePayroll>(JsonConvert.DeserializeObject<List<EmployeePayroll>>(result));
            return View(result);
        }

        // GET: EmployeePayrolls/Details/5
        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrievePayroll(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: EmployeePayrolls/Create
        public IActionResult Create(Guid id)
        {
            var employeePayroll = new EmployeePayroll()
            {
                EmployeeId = id,
                Date = DateTime.Now,
            };

            return View(employeePayroll);
        }

        // POST: EmployeePayrolls/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeeId,Date,Amount")] EmployeePayroll employeePayroll)
        {
            await UpdatePayroll(employeePayroll);
            ModelState.Clear();

            var newEmployeePayroll = new EmployeePayroll()
            {
                EmployeeId = employeePayroll.Id,
                Date = DateTime.Now,
            };

            return View(newEmployeePayroll);
        }

        // GET: EmployeePayrolls/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrievePayroll(id));
        }

        // POST: EmployeePayrolls/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,EmployeeId,Date,Amount")] EmployeePayroll employeePayroll)
        {
            await UpdatePayroll(employeePayroll);
            return RedirectToAction("Details", "Employees", new { id = employeePayroll.EmployeeId });
        }

        // GET: EmployeePayrolls/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrievePayroll(id));
        }

        // POST: EmployeePayrolls/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid employeeId)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employeepayroll/DeleteEmployeePayroll", json);
            return RedirectToAction("Details", "Employees", new { id = employeeId });
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }

        public RedirectToActionResult BackToList(Guid id)
        {
            return RedirectToAction("Details", "Employees", new { id });
        }

        private async Task UpdatePayroll(EmployeePayroll employeeCertification)
        {
            var request = new UpdateEmployeePayrollRequest()
            {
                Id = employeeCertification.Id == Guid.Empty ? Guid.NewGuid() : employeeCertification.Id,
                EmployeeId = employeeCertification.EmployeeId,
                Date = DateTime.Now,
                Amount = employeeCertification.Amount
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employeepayroll/UpdateEmployeePayroll", json);
        }

        private async Task<EmployeePayroll> RetrievePayroll(Guid id)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employeepayroll/GetEmployeePayroll", json);
            var certification = JsonConvert.DeserializeObject<EmployeePayroll>(result);
            return certification;
        }
    }
}
