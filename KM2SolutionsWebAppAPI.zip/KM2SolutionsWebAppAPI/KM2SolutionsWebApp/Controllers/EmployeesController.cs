﻿using Microsoft.AspNetCore.Mvc;
using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsWebApp.Models;
using KM2SolutionsWebApp.Services;
using Azure.Core;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeesController : Controller
    {
      
        // GET: Employees
        public async Task<IActionResult> Index()
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employee/GetEmployees");
            var employees = new List<Employee>(JsonConvert.DeserializeObject<List<Employee>>(result));
            return View(employees);
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveEmployee(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }


        // GET: Employees/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FirstName,LastName,StartDate,EndDate")] Employee employee)
        {
            await UpdateEmployee(employee);
            ModelState.Clear();
            return View();
        }

        // GET: Employees/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrieveEmployee(id));
        }

        // POST: Employees/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,FirstName,LastName,StartDate,EndDate")] Employee employee)
        {
            await UpdateEmployee(employee);
            return RedirectToAction(nameof(Index));
        }

        // GET: Employees/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrieveEmployee(id));
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employee/DeleteEmployee", json);
            return RedirectToAction(nameof(Index));      
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }

        public RedirectToActionResult ToAction(Guid id, string actionName, string control)
        {
            return RedirectToAction(control, actionName, new { id });
        }

        private async Task UpdateEmployee(Employee employee)
        {
            var request = new UpdateEmployeeRequest()
            {
                ID = employee.Id == Guid.Empty ? Guid.NewGuid() : employee.Id,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                StartDate = employee.StartDate,
                EndDate = employee.EndDate
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employee/UpdateEmployee", json);
        }

        private async Task<Employee> RetrieveEmployee(Guid id)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employee/GetEmployee", json);
            var employee = JsonConvert.DeserializeObject<Employee>(result);
            return employee;
        }
    }
}
