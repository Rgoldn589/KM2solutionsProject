﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Models;
using KM2SolutionsWebApp.Services;
using KM2SolutionsWebApp.API.Requests;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeeJobHistoriesController : Controller
    {

        // GET: EmployeeJobHistories
        public async Task<IActionResult> Index(Guid id)
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employeejobhistory/GetEmployeeJobHistories");
            var employees = new List<Employee>(JsonConvert.DeserializeObject<List<Employee>>(result));
            return View(result);
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: EmployeeJobHistories/Details/5
        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveHistory(id));
        }

        // GET: EmployeeJobHistories/Create
        public IActionResult Create(Guid id)
        {
            ViewData["EmployeeId"] = id;

            var employeeJobHistory = new EmployeeJobHistory()
            {
                EmployeeId = id,
                StartDate = null,
                EndDate = null,
            };

            return View(employeeJobHistory);
        }

        // POST: EmployeeJobHistories/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeeId,Job,StartDate,EndDate,TotalHours")] EmployeeJobHistory employeeJobHistory)
        {
            await UpdateHistory(employeeJobHistory);
            ModelState.Clear();

            var jobHistory = new EmployeeJobHistory()
            {
                EmployeeId = employeeJobHistory.Id,
                StartDate = null,
                EndDate = null,
            };
   
            return View(jobHistory);
        }

        // GET: EmployeeJobHistories/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrieveHistory(id));
        }

        // POST: EmployeeJobHistories/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,EmployeeId,Job,StartDate,EndDate,TotalHours")] EmployeeJobHistory employeeJobHistory)
        {
            await UpdateHistory(employeeJobHistory);
            return RedirectToAction("Details", "Employees", new { id = employeeJobHistory.EmployeeId });
        }

        // GET: EmployeeJobHistories/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrieveHistory(id));
        }

        // POST: EmployeeJobHistories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid employeeId)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employeejobhistory/DeleteEmployeeJobHistory", json);
            return RedirectToAction("Details", "Employees", new { id = employeeId });
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }

        public RedirectToActionResult BackToList(Guid id)
        {
            return RedirectToAction("Details", "Employees", new { id });
        }

        private async Task UpdateHistory(EmployeeJobHistory employeeJobHistory)
        {
            var request = new UpdateEmployeeJobHistoryRequest()
            {
                Id = employeeJobHistory.Id == Guid.Empty ? Guid.NewGuid() : employeeJobHistory.Id,
                EmployeeId = employeeJobHistory.EmployeeId,
                Job = employeeJobHistory.Job,
                TotalHours = employeeJobHistory.TotalHours,
                StartDate = employeeJobHistory.StartDate,
                EndDate = employeeJobHistory.EndDate
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employeejobhistory/UpdateEmployeeJobHistory", json);
        }

        private async Task<EmployeeJobHistory> RetrieveHistory(Guid id)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employeejobhistory/GetEmployeeJobHistory", json);
            var history = JsonConvert.DeserializeObject<EmployeeJobHistory>(result);
            return history;
        }
    }
}
