﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Models;
using KM2SolutionsWebApp.API.Requests;
using KM2SolutionsWebApp.Services;
using NuGet.Protocol;
using Newtonsoft.Json;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeeCertificatesController : Controller
    {

        // GET: EmployeeCertificates
        public async Task<IActionResult> Index(Guid id)
        {
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employeecertificate/GetEmployeeCertificates");
            var employees = new List<EmployeeCertificate>(JsonConvert.DeserializeObject<List<EmployeeCertificate>>(result));
            return View(result);
        }

        // GET: EmployeeCertificates/Details/5
        public async Task<IActionResult> Details(Guid id)
        {
            return View(await RetrieveCertificate(id));
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: EmployeeCertificates/Create
        public IActionResult Create(Guid id)
        {
            ViewData["EmployeeId"] = id;

            var employeeCertificate = new EmployeeCertificate()
            {
                EmployeeId = id,
                Date = DateTime.Now
            };

            return View(employeeCertificate);
        }

        // POST: EmployeeCertificates/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeeId,Name,Description,Date")] EmployeeCertificate employeeCertificate)
        {
            UpdateCertificate(employeeCertificate);
            ModelState.Clear();
            return View();
        }

        // GET: EmployeeCertificates/Edit/5
        public async Task<IActionResult> Edit(Guid id)
        {
            return View(await RetrieveCertificate(id));
        }

        // POST: EmployeeCertificates/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,EmployeeId,Name,Description,Date")] EmployeeCertificate employeeCertificate)
        {
            UpdateCertificate(employeeCertificate);
            return RedirectToAction("Details", "Employees", new { id = employeeCertificate.EmployeeId });
        }

        // GET: EmployeeCertificates/Delete/5
        public async Task<IActionResult> Delete(Guid id)
        {
            return View(await RetrieveCertificate(id));
        }

        // POST: EmployeeCertificates/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid employeeId)
        {

            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employeecertificate/DeleteEmployeeCertificate", json);
            return RedirectToAction("Details", "Employees", new { id = employeeId });
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }

        public RedirectToActionResult BackToList(Guid id)
        {
            return RedirectToAction("Details", "Employees", new { id });
        }

        private async Task UpdateCertificate(EmployeeCertificate certificate)
        {
            var request = new UpdateEmployeeCertificateRequest()
            {
                Id = certificate.Id == Guid.Empty ? Guid.NewGuid() : certificate.Id,
                Name = certificate.Name,
                EmployeeId = certificate.EmployeeId,
                Description = certificate.Description,
                Date = DateTime.Now,
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            await new CallAPIService().MakeAPICall(HttpMethod.Post, "employeecertificate/UpdateEmployeeCertificate", json);
        }

        private async Task<EmployeeCertificate> RetrieveCertificate(Guid id)
        {
            var request = new GetEmployeeDataRequest()
            {
                ID = id
            };

            var json = JsonConvert.SerializeObject(request, Formatting.Indented);
            var result = await new CallAPIService().MakeAPICall(HttpMethod.Get, "employeecertificate/GetEmployeeCertificate", json);
            var employeeCertificate = JsonConvert.DeserializeObject<EmployeeCertificate>(result);
            return employeeCertificate;
        }
    }
}
