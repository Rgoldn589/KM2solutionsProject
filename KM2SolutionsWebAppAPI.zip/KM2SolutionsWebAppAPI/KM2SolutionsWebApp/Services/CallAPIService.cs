﻿namespace KM2SolutionsWebApp.Services
{
    public class CallAPIService
    {
        public async Task<string> MakeAPICall(HttpMethod method, string http, string? json = null)
        {
            var config = new ConfigurationBuilder()
                        .AddJsonFile("appsettings.json")
                        .Build();

            var httpBase = config["HTTP"];

            var httpClient = new HttpClient();
            var newRequest = new HttpRequestMessage(method, httpBase + http);

            if (json != null)
            {
                newRequest.Content = new StringContent(json, null, "application/json");
            }

            var response = await httpClient.SendAsync(newRequest);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadAsStringAsync();
        }
    }
}
