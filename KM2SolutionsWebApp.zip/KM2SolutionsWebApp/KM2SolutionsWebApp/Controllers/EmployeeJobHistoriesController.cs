﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Data;
using KM2SolutionsWebApp.Models;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeeJobHistoriesController : Controller
    {
        private readonly KM2SolutionsWebAppContext _context;

        public EmployeeJobHistoriesController(KM2SolutionsWebAppContext context)
        {
            _context = context;
        }

        // GET: EmployeeJobHistories
        public async Task<IActionResult> Index(Guid id)
        {
            ViewData["EmpId"] = id;
            var kM2SolutionsWebAppContext = _context.EmployeeJobHistory.Where(e => e.EmployeeId == id)
                                                                 .Include(e => e.Employee);

            return View(await kM2SolutionsWebAppContext.ToListAsync());
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: EmployeeJobHistories/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeJobHistory = await _context.EmployeeJobHistory
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employeeJobHistory == null)
            {
                return NotFound();
            }

            return View(employeeJobHistory);
        }

        // GET: EmployeeJobHistories/Create
        public IActionResult Create(Guid id)
        {
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName");

            var employeeHistory = new EmployeeJobHistory()
            {
                EmployeeId = id,
                StartDate = DateTime.Now,
                EndDate = null
            };

            return View(employeeHistory);
        }

        // POST: EmployeeJobHistories/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeeId,Job,StartDate,EndDate,TotalHours")] EmployeeJobHistory employeeJobHistory)
        {
            if (ModelState.IsValid)
            {
                employeeJobHistory.Id = Guid.NewGuid();
                _context.Add(employeeJobHistory);
                await _context.SaveChangesAsync();
                return RedirectToAction("Details", "Employees", new { id = employeeJobHistory.EmployeeId });
            }

            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeeJobHistory.EmployeeId);
            return View(employeeJobHistory);
        }

        // GET: EmployeeJobHistories/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeJobHistory = await _context.EmployeeJobHistory.FindAsync(id);
            if (employeeJobHistory == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeeJobHistory.EmployeeId);
            return View(employeeJobHistory);
        }

        // POST: EmployeeJobHistories/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,EmployeeId,Job,StartDate,EndDate,TotalHours")] EmployeeJobHistory employeeJobHistory)
        {
            if (id != employeeJobHistory.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employeeJobHistory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeJobHistoryExists(employeeJobHistory.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), new { id = employeeJobHistory.EmployeeId });
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeeJobHistory.EmployeeId);
            return View(employeeJobHistory);
        }

        // GET: EmployeeJobHistories/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeJobHistory = await _context.EmployeeJobHistory
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employeeJobHistory == null)
            {
                return NotFound();
            }

            return View(employeeJobHistory);
        }

        // POST: EmployeeJobHistories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid employeeId)
        {
            var employeeJobHistory = await _context.EmployeeJobHistory.FindAsync(id);
            if (employeeJobHistory != null)
            {
                _context.EmployeeJobHistory.Remove(employeeJobHistory);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index), new { id = employeeId });
        }

        private bool EmployeeJobHistoryExists(Guid id)
        {
            return _context.EmployeeJobHistory.Any(e => e.Id == id);
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }
    }
}
