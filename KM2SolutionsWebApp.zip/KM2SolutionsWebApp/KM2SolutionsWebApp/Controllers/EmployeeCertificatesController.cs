﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Data;
using KM2SolutionsWebApp.Models;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeeCertificatesController : Controller
    {
        private readonly KM2SolutionsWebAppContext _context;
        public EmployeeCertificatesController(KM2SolutionsWebAppContext context)
        {
            _context = context;
        }

        // GET: EmployeeCertificates
        public async Task<IActionResult> Index(Guid id)
        {

            ViewData["EmpId"] = id;
            var kM2SolutionsWebAppContext = await _context.EmployeeCertificate.Where(e => e.EmployeeId == id)
                                                                    .Include(e => e.Employee)
                                                                    .ToListAsync();
            return View(kM2SolutionsWebAppContext);
        }

        // GET: EmployeeCertificates/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeCertificate = await _context.EmployeeCertificate.FindAsync(id);
            if (employeeCertificate == null)
            {
                return NotFound();
            }

            return View(employeeCertificate);
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: EmployeeCertificates/Create
        public IActionResult Create(Guid id)
        {

            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName");

            var employeeCertificate = new EmployeeCertificate()
            {
               EmployeeId = id,
               Date = DateTime.Now
            };

            return View(employeeCertificate);
        }

        // POST: EmployeeCertificates/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeeId,Name,Description,Date")] EmployeeCertificate employeeCertificate)
        {
            if (ModelState.IsValid)
            {
                employeeCertificate.Id = Guid.NewGuid();
                _context.Add(employeeCertificate);
                await _context.SaveChangesAsync();
                return RedirectToAction("Details", "Employees", new { id = employeeCertificate.EmployeeId });
            }

            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeeCertificate.EmployeeId);
            return View(employeeCertificate);
        }

        // GET: EmployeeCertificates/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeCertificate = await _context.EmployeeCertificate.FindAsync(id);
            if (employeeCertificate == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeeCertificate.EmployeeId);
            return View(employeeCertificate);
        }

        // POST: EmployeeCertificates/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,EmployeeId,Name,Description,Date")] EmployeeCertificate employeeCertificate)
        {
            if (id != employeeCertificate.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employeeCertificate);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeCertificateExists(employeeCertificate.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), new {id =  employeeCertificate.EmployeeId });
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeeCertificate.EmployeeId);
            return View(employeeCertificate);
        }

        // GET: EmployeeCertificates/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeCertificate = await _context.EmployeeCertificate.FindAsync(id);
            if (employeeCertificate == null)
            {
                return NotFound();
            }

            return View(employeeCertificate);
        }

        // POST: EmployeeCertificates/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid employeeId)
        {
            var employeeCertificate = await _context.EmployeeCertificate.FindAsync(id);
            if (employeeCertificate != null)
            {
                _context.EmployeeCertificate.Remove(employeeCertificate);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index), new { id = employeeId });
        }

        private bool EmployeeCertificateExists(Guid id)
        {
            return _context.EmployeeCertificate.Any(e => e.Id == id);
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }
    }
}
