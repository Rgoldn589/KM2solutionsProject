﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Data;
using KM2SolutionsWebApp.Models;

namespace KM2SolutionsWebApp.Controllers
{
    public class EmployeePayrollsController : Controller
    {
        private readonly KM2SolutionsWebAppContext _context;

        public EmployeePayrollsController(KM2SolutionsWebAppContext context)
        {
            _context = context;
        }

        // GET: EmployeePayrolls
        public async Task<IActionResult> Index(Guid id)
        {
            ViewData["EmpId"] = id;
            var kM2SolutionsWebAppContext = _context.EmployeePayroll.Where(e => e.EmployeeId == id)
                                                                    .Include(e => e.Employee);

            return View(await kM2SolutionsWebAppContext.ToListAsync());
        }

        // GET: EmployeePayrolls/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeePayroll = await _context.EmployeePayroll
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employeePayroll == null)
            {
                return NotFound();
            }

            return View(employeePayroll);
        }

        public void Redirect(string http)
        {
            Response.Redirect(http);
        }

        // GET: EmployeePayrolls/Create
        public IActionResult Create(Guid id)
        {
            var employeePayroll = new EmployeePayroll()
            {
                EmployeeId = id,
                Date = DateTime.Now,
            };

            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName");
            return View(employeePayroll);
        }

        // POST: EmployeePayrolls/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,EmployeeId,Date,Amount")] EmployeePayroll employeePayroll)
        {
            if (ModelState.IsValid)
            {
                employeePayroll.Id = Guid.NewGuid();
                _context.Add(employeePayroll);
                await _context.SaveChangesAsync();
                return RedirectToAction("Details","Employees", new {id = employeePayroll.EmployeeId });
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeePayroll.EmployeeId);
            return View(employeePayroll);
        }

        // GET: EmployeePayrolls/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeePayroll = await _context.EmployeePayroll.FindAsync(id);
            if (employeePayroll == null)
            {
                return NotFound();
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeePayroll.EmployeeId);
            return View(employeePayroll);
        }

        // POST: EmployeePayrolls/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,EmployeeId,Date,Amount")] EmployeePayroll employeePayroll)
        {
            if (id != employeePayroll.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employeePayroll);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeePayrollExists(employeePayroll.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index), new { id = employeePayroll.EmployeeId });
            }
            ViewData["EmployeeId"] = new SelectList(_context.Employee, "Id", "FirstName", employeePayroll.EmployeeId);
            return View(employeePayroll);
        }

        // GET: EmployeePayrolls/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeePayroll = await _context.EmployeePayroll
                .Include(e => e.Employee)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employeePayroll == null)
            {
                return NotFound();
            }

            return View(employeePayroll);
        }

        // POST: EmployeePayrolls/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id, Guid employeeId)
        {
            var employeePayroll = await _context.EmployeePayroll.FindAsync(id);
            if (employeePayroll != null)
            {
                _context.EmployeePayroll.Remove(employeePayroll);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index), new { id = employeeId });
        }

        private bool EmployeePayrollExists(Guid id)
        {
            return _context.EmployeePayroll.Any(e => e.Id == id);
        }

        public void Employee(Guid? id)
        {
            Response.Redirect("https://localhost:7198/Employees/Details?id=" + id);
        }
    }
}
