﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using KM2SolutionsWebApp.Models;

namespace KM2SolutionsWebApp.Data
{
    public class KM2SolutionsWebAppContext : DbContext
    {
        public KM2SolutionsWebAppContext (DbContextOptions<KM2SolutionsWebAppContext> options)
            : base(options)
        {
        }

        public DbSet<KM2SolutionsWebApp.Models.Employee> Employee { get; set; } = default!;
        public DbSet<KM2SolutionsWebApp.Models.EmployeeCertificate> EmployeeCertificate { get; set; } = default!;
        public DbSet<KM2SolutionsWebApp.Models.EmployeeJobHistory> EmployeeJobHistory { get; set; } = default!;
        public DbSet<KM2SolutionsWebApp.Models.EmployeePayroll> EmployeePayroll { get; set; } = default!;
    }
}
