﻿using System.ComponentModel.DataAnnotations;

namespace KM2SolutionsWebApp.Models
{
    public class EmployeeCertificate
    {
        public Guid Id { get; set; }

        public Guid? EmployeeId { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        [Required]
        public string Description { get; set; } = null!;

        [Required]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime Date { get; set; }

        public virtual Employee? Employee { get; set; }
    }
}
