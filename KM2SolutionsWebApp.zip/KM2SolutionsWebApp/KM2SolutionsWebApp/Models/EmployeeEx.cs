﻿namespace KM2SolutionsWebApp.Models
{
    public partial class Employee
    {
        public string EmployeeFullName
        {
            get { return FirstName + " " + LastName; }
        }

        public List<EmployeeCertificate> EmployeeCertificates { get; set; }

        public List<EmployeeJobHistory> EmployeeJobHistories{ get; set; }

        public List<EmployeePayroll> EmployeePayrolls{ get; set; }

    }
}
