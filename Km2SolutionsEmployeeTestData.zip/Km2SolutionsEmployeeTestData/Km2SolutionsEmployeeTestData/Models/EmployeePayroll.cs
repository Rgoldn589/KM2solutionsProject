﻿
namespace Km2SolutionsEmployeeTestData.Models
{
    public partial class EmployeePayroll
    {
        public Guid Id { get; set; }

        public Guid? EmployeeId { get; set; }

        public DateTime? Date { get; set; }

        public decimal Amount { get; set; }

    }
}