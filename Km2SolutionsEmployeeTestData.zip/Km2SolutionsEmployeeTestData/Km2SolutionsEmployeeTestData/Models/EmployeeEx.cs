﻿
using System.Collections.ObjectModel;

namespace Km2SolutionsEmployeeTestData.Models
{
    public partial class Employee
    {
        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }

        public static List<Employee> GetAllEmployees()
        {
            var empGuid = Guid.NewGuid();

            return new List<Employee>()
            {
            new Employee()
            {
                Id = empGuid,
                FirstName = "John",
                LastName = "Smith",
                StartDate = new DateTime(2019, 1, 1),
                EndDate = null,
                EmployeeCertificates = new List<EmployeeCertificate>()
                {
                    new EmployeeCertificate()
                    {
                       Id = empGuid,
                       EmployeeId = Guid.NewGuid(),
                       Name = "Programmer I",
                       Description = "Entry Level Programmer",
                       Date = new DateTime(2020, 2, 1)
                    },

                    new EmployeeCertificate()
                    {
                       Id = empGuid,
                       EmployeeId = Guid.NewGuid(),
                       Name = "Database I",
                       Description = "Entry Level DBA",
                       Date = new DateTime(2020, 2, 1)
                    }
                },

                EmployeeJobHistories = new List<EmployeeJobHistory>()
                {
                    new EmployeeJobHistory()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Job = "Jersey Project",
                        StartDate = new DateTime(2015, 5, 23),
                        EndDate = new DateTime(2015, 8, 1),
                        TotalHours = 275
                    },

                    new EmployeeJobHistory()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Job = "Lancaster Project",
                        StartDate = new DateTime(2019, 12, 1),
                        EndDate = new DateTime(2020, 1, 1),
                        TotalHours = 15.25m
                    },
                },

                EmployeePayrolls = new List<EmployeePayroll>()
                {
                    new EmployeePayroll()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Date = new DateTime(2020, 1, 1),
                        Amount = 23215.25m
                    },

                    new EmployeePayroll()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Date = new DateTime(2015, 8, 1),
                        Amount = 2275.00m
                    }
                }
            },


            new Employee()
            {
                Id =  empGuid = Guid.NewGuid(),
                FirstName = "Jane",
                LastName = "Doe",
                StartDate = new DateTime(2020, 3, 30),
                EndDate = new DateTime(2022, 1, 1),
                EmployeeCertificates = new List<EmployeeCertificate>()
                {
                    new EmployeeCertificate()
                    {
                        Id = empGuid,
                        EmployeeId = Guid.NewGuid(),
                        Name = "Datebase II",
                        Description = "Intermediate Level DBA",
                        Date = new DateTime(2015, 6, 1)
                    },

                    new EmployeeCertificate()
                    {
                        Id = empGuid,
                        EmployeeId = Guid.NewGuid(),
                        Name = "Programmer II",
                        Description = "Intermediate Level Programmer",
                        Date = new DateTime(2019, 1, 1)
                    }
                },

                EmployeeJobHistories = new List<EmployeeJobHistory>()
                {
                    new EmployeeJobHistory()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Job = "Orlando Project",
                        StartDate = new DateTime(2023, 4, 18),
                        EndDate = new DateTime(2017, 10, 20),
                        TotalHours = 275
                    },

                    new EmployeeJobHistory()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Job = "Philly Project",
                        StartDate = new DateTime(2017, 10, 20),
                        EndDate = new DateTime(2017, 12, 6),
                        TotalHours = 15.25m
                    }
                },

                EmployeePayrolls = new List<EmployeePayroll>()
                {
                    new EmployeePayroll()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Date = new DateTime(2017, 12, 6),
                        Amount = 440.10m
                    },

                    new EmployeePayroll()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Date = new DateTime(2023, 11, 15),
                        Amount = 1287.98m
                    }
                }
            },

            new Employee()
            {
                Id = empGuid = Guid.NewGuid(),
                FirstName = "Samantha",
                LastName = "Jones",
                StartDate = new DateTime(2015, 8, 7),
                EndDate = new DateTime(2020, 4, 3)
            },

            new Employee()
            {
                Id = empGuid = Guid.NewGuid(),
                FirstName = "Sam",
                LastName = "Smith",
                StartDate = new DateTime(2023, 4, 7),
                EndDate = null,
                EmployeeCertificates = new List<EmployeeCertificate>()
                {
                    new EmployeeCertificate()
                    {
                       Id = empGuid,
                       EmployeeId = Guid.NewGuid(),
                       Name = "Datebase III",
                       Description = "Senior Level DBA",
                       Date = new DateTime(2023, 8, 1)
                    },

                    new EmployeeCertificate()
                    {
                       Id = empGuid,
                       EmployeeId = Guid.NewGuid(),
                       Name = "Programmer III",
                       Description = "Senior Level Programmer",
                       Date = new DateTime(2020, 4, 1)
                    }
                },

                EmployeeJobHistories = new List<EmployeeJobHistory>()
                {
                    new EmployeeJobHistory()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Job = "Tampa Project",
                        StartDate = new DateTime(2020, 6, 4),
                        EndDate = new DateTime(2021, 8, 1),
                        TotalHours = 275
                    },

                    new EmployeeJobHistory()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Job = "Jacksonville Project",
                        StartDate = new DateTime(2021, 9, 7),
                        EndDate = new DateTime(2022, 1, 11),
                        TotalHours = 15.25m
                    }
                },

                EmployeePayrolls = new List<EmployeePayroll>()
                {
                    new EmployeePayroll()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Date = new DateTime(2022, 1, 11),
                        Amount = 675.45m
                    },

                    new EmployeePayroll()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = empGuid,
                        Date = new DateTime(2020, 8, 1),
                        Amount = 3100.76m
                    }
                }
            }};
        }
    }
}
