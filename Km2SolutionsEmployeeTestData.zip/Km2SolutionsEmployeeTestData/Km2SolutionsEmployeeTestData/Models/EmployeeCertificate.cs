﻿using System;
using System.Collections.Generic;

namespace Km2SolutionsEmployeeTestData.Models
{
    public partial class EmployeeCertificate
    {
        public Guid Id { get; set; }

        public Guid? EmployeeId { get; set; }

        public string Name { get; set; } = null!;

        public string Description { get; set; } = null!;

        public DateTime Date { get; set; }
    }
}
