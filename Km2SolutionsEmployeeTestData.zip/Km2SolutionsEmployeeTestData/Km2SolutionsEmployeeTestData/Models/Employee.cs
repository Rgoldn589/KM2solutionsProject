﻿
namespace Km2SolutionsEmployeeTestData.Models
{
    public partial class Employee
    {
        public Guid Id { get; set; }

        public string FirstName { get; set; } = null!;

        public string LastName { get; set; } = null!;

        public DateTime StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public virtual ICollection<EmployeeCertificate> EmployeeCertificates { get; set; } = new List<EmployeeCertificate>();

        public virtual ICollection<EmployeeJobHistory> EmployeeJobHistories { get; set; } = new List<EmployeeJobHistory>();

        public virtual ICollection<EmployeePayroll> EmployeePayrolls { get; set; } = new List<EmployeePayroll>();

    }
}
