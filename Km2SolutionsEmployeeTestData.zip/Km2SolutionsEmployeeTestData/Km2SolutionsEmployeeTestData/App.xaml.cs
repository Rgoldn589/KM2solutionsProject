﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Km2SolutionsEmployeeTestData
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
