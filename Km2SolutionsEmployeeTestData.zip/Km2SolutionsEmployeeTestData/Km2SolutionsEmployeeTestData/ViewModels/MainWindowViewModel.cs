﻿using Km2SolutionsEmployeeTestData.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace KMSolutionsEmployee.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged = null;
        public ObservableCollection<Employee>? Employees { get; set; }

        private Employee? selectedEmployee;
        public Employee? SelectedEmployee
        {
            get { return selectedEmployee; }
            set
            {
                SetField(ref selectedEmployee, value, "selectedEmployee");
            }
        }

        public MainWindowViewModel()
        {
            Employees = new ObservableCollection<Employee>(Employee.GetAllEmployees());
        }


        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null)
                return;

            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetField<T>(ref T field, T value, string propertyName)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}
